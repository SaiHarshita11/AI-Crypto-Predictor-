# train_all.py
"""
Train models for all coins.

Usage:
  python train_all.py                # sequential, 1 epoch quick train (default)
  python train_all.py --epochs 5     # sequential, 5 epochs
  python train_all.py --parallel 4   # parallel training with 4 worker processes
  python train_all.py --parallel 2 --epochs 3
"""

import argparse
import os
import sys
import traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing

# Ensure project root is on sys.path so importing futurecoin_end2end works
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Import train function and constants from your module
from futurecoin_end2end import train_and_save, LOOKBACK_HOURLY, LOOKBACK_DAILY, COMMON_COINS

def _train_task(args):
    """
    Worker wrapper function executed in a separate process.
    Args is a tuple: (coin, freq, lookback, epochs, batch_size)
    Returns a tuple: (coin, freq, success_bool, message)
    """
    coin, freq, lookback, epochs, batch_size = args
    try:
        # Import inside worker to avoid pickling TF objects
        # (train_and_save is a top-level function so it should be picklable,
        #  but re-importing is a simple safety measure)
        from futurecoin_end2end import train_and_save
        # Run training
        model_path, scaler_path = train_and_save(coin, freq, lookback, epochs=epochs, batch_size=batch_size)
        return (coin, freq, True, f"Saved model: {model_path}, scaler: {scaler_path}")
    except Exception as e:
        tb = traceback.format_exc()
        return (coin, freq, False, f"Error: {e}\n{tb}")

def sequential_train(coins, epochs, batch_size):
    for coin in coins:
        for freq, lookback in [('hourly', LOOKBACK_HOURLY), ('daily', LOOKBACK_DAILY)]:
            print(f"\n[SEQUENTIAL] Training {coin} - {freq} (epochs={epochs}, batch_size={batch_size})")
            try:
                train_and_save(coin, freq, lookback, epochs=epochs, batch_size=batch_size)
            except Exception as e:
                print(f"[ERROR] Failed training {coin} {freq}: {e}")
                traceback.print_exc()

def parallel_train(coins, epochs, batch_size, workers):
    # Build tasks list
    tasks = []
    for coin in coins:
        for freq, lookback in [('hourly', LOOKBACK_HOURLY), ('daily', LOOKBACK_DAILY)]:
            tasks.append((coin, freq, lookback, epochs, batch_size))

    # Set multiprocessing start method to 'spawn' for TF compatibility
    try:
        multiprocessing.set_start_method("spawn", force=True)
    except RuntimeError:
        # Start method already set; ignore
        pass

    print(f"[PARALLEL] Starting ProcessPoolExecutor with {workers} workers...")
    results = []
    with ProcessPoolExecutor(max_workers=workers) as ex:
        future_to_task = {ex.submit(_train_task, t): t for t in tasks}
        for fut in as_completed(future_to_task):
            t = future_to_task[fut]
            try:
                coin, freq, ok, msg = fut.result()
                if ok:
                    print(f"[OK] {coin} {freq}: {msg}")
                else:
                    print(f"[FAIL] {coin} {freq}: {msg}")
                results.append((coin, freq, ok, msg))
            except Exception as e:
                print(f"[EXC] Task {t} raised: {e}")
                traceback.print_exc()
    return results

def parse_args():
    p = argparse.ArgumentParser(description="Train models for all common coins.")
    p.add_argument("--parallel", "-p", type=int, default=0,
                   help="If >0, run training in parallel using N worker processes. Default 0 (sequential).")
    p.add_argument("--epochs", "-e", type=int, default=1, help="Number of epochs for training (default 1).")
    p.add_argument("--batch-size", "-b", type=int, default=32, help="Batch size for training (default 32).")
    p.add_argument("--coins", "-c", type=str, default="all",
                   help="Comma-separated list of coins to train (e.g. BTCUSDT,ETHUSDT) or 'all' to use COMMON_COINS.")
    return p.parse_args()

def main():
    args = parse_args()

    if args.coins.strip().lower() == "all":
        coins = COMMON_COINS
    else:
        coins = [c.strip().upper() for c in args.coins.split(",") if c.strip()]

    print("TRAIN ALL CONFIG:")
    print(f"  coins: {coins}")
    print(f"  epochs: {args.epochs}")
    print(f"  batch_size: {args.batch_size}")
    print(f"  parallel_workers: {args.parallel if args.parallel>0 else 'sequential'}")
    print("WARNING: Parallel training may exhaust CPU/GPU and RAM. Use with caution.\n")

    if args.parallel and args.parallel > 0:
        workers = max(1, args.parallel)
        results = parallel_train(coins, epochs=args.epochs, batch_size=args.batch_size, workers=workers)
        # Summarize
        ok = sum(1 for r in results if r[2])
        total = len(results)
        print(f"\n[SUMMARY] {ok}/{total} tasks succeeded.")
    else:
        sequential_train(coins, epochs=args.epochs, batch_size=args.batch_size)
        print("\n[SUMMARY] Sequential training completed.")

if __name__ == "__main__":
    main()
