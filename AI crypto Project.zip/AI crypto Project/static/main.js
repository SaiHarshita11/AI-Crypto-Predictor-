// main.js — frontend logic for FutureCoin dashboard (neon theme, prediction + history ready)

/* --- simple client-side auth guard (redirects to /login if not logged in) --- */
function getCurrentUser() {
  let v = sessionStorage.getItem("fc_current_user") || localStorage.getItem("fc_current_user");
  return v ? JSON.parse(v) : null;
}
(function() {
  // allow login page to load freely
  if (window.location.pathname.endsWith("/login")) return;
  const cur = getCurrentUser();
  if (!cur || !cur.email) {
    window.location.href = "/login";
  }
})();

/* --- logout handler --- */
document.addEventListener("DOMContentLoaded", () => {
  const logoutEl = document.getElementById("logoutLink");
  if (logoutEl) {
    logoutEl.onclick = async () => {
      // clear browser storage
      localStorage.removeItem("fc_current_user");
      sessionStorage.removeItem("fc_current_user");
      // also clear server session if possible
      try { await fetch("/logout"); } catch(e) {}
      // redirect to login
      window.location.href = "/login";
    };
  }
});

/* If your Flask runs on a different host/port, change this base URL. */
const API_BASE = ""; // same origin by default

/* Elements */
const predictBtn = document.getElementById('predictBtn');
const finalValueEl = document.getElementById('finalValue');
const metricsArea = document.getElementById('metricsArea');
const errorArea = document.getElementById('errorArea');

/* Neon stat elements */
const currentPriceEl = document.getElementById('currentPrice');
const changeValueEl = document.getElementById('changeValue');
const changePercentEl = document.getElementById('changePercent');
const directionEl = document.getElementById('direction');

let chart = null;

/* Helpers */
function setLoading(isLoading) {
  if (predictBtn) {
    predictBtn.disabled = isLoading;
    predictBtn.textContent = isLoading ? 'Predicting...' : 'Get Prediction';
  }
}
function showError(msg) { if (errorArea) errorArea.textContent = msg; }
function clearError() { if (errorArea) errorArea.textContent = ""; }

function buildPayload() {
  const coin = document.getElementById('coin').value;
  const timeframe = document.getElementById('timeframe').value;
  let steps = parseInt(document.getElementById('steps').value);
  if (isNaN(steps) || steps < 1) steps = 1;
  const graph = document.getElementById('graph').value;
  const mode = document.getElementById('mode').value;
  return { coin, timeframe, steps, graph, mode };
}

async function callApi(payload) {
  const endpoint = (payload.mode === 'fast') ? '/api/predict_fast' : '/api/predict';
  const url = API_BASE + endpoint;
  const body = {
    coin: payload.coin,
    timeframe: payload.timeframe,
    steps: payload.steps
  };
  return fetch(url, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(body)
  });
}

/* Neon chart renderer
   - maintainAspectRatio: false so CSS wrapper (.chart-wrap) controls size
   - responsive: true
   - bar sizing tweaked so bars look good in medium container
*/
function renderChart(labels, values, coin, chartType) {
  const canvas = document.getElementById('predictionChart');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  if (chart) { try { chart.destroy(); } catch (e) {} }

  const commonDataset = {
    label: `${coin} prediction (INR)`,
    data: values,
    tension: 0.2,
    pointRadius: 4,
    borderWidth: 2,
    borderColor: 'rgba(0,245,255,0.95)',
    backgroundColor: 'rgba(0,245,255,0.06)',
    fill: false
  };
  const barDataset = {
    ...commonDataset,
    borderColor: 'rgba(255,0,160,0.95)',
    backgroundColor: 'rgba(255,0,160,0.14)',
    fill: true
  };

  chart = new Chart(ctx, {
    type: chartType === 'bar' ? 'bar' : 'line',
    data: {
      labels,
      datasets: [ chartType === 'bar' ? barDataset : commonDataset ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false, // allow wrapper to set size
      layout: { padding: 6 },
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: function(context) {
              const v = context.raw;
              if (v === undefined || v === null) return '';
              return '₹ ' + Number(v).toLocaleString('en-IN', { maximumFractionDigits: 2 });
            }
          }
        }
      },
      elements: {
        bar: {
          // keep bars pleasantly sized inside medium container
          maxBarThickness: 80,
          barPercentage: 0.6,
          categoryPercentage: 0.66
        },
        line: {
          tension: 0.2
        }
      },
      scales: {
        x: {
          grid: { color: 'rgba(255,255,255,0.03)' },
          ticks: { color: '#dddddd' }
        },
        y: {
          beginAtZero: false,
          grid: { color: 'rgba(255,255,255,0.03)' },
          ticks: {
            color: '#dddddd',
            callback: function(v) {
              if (v === undefined || v === null) return v;
              return '₹' + Number(v).toLocaleString('en-IN', { maximumFractionDigits: 2 });
            }
          }
        }
      }
    }
  });
}

/* Utility */
function safeSetText(el, text) { if (el) el.textContent = text; }

/* Populate neon stat boxes */
function populateStatBoxes(data, finalFromPreds) {
  const curr = data.current_price_inr ||
    (Array.isArray(data.predictions_inr) && data.predictions_inr.length ? data.predictions_inr[0] : null);
  if (curr != null && currentPriceEl) {
    safeSetText(currentPriceEl, "₹ " + Number(curr).toLocaleString('en-IN', { maximumFractionDigits: 2 }));
  }

  const finalVal = data.final_inr || finalFromPreds ||
    (Array.isArray(data.predictions_inr) && data.predictions_inr.length ? data.predictions_inr[data.predictions_inr.length - 1] : null);
  if (finalVal != null && finalValueEl) {
    safeSetText(finalValueEl, "₹ " + Number(finalVal).toLocaleString('en-IN', { maximumFractionDigits: 2 }));
  }

  if (data.change_inr != null && changeValueEl) {
    safeSetText(changeValueEl, "₹ " + Number(data.change_inr).toLocaleString('en-IN', { maximumFractionDigits: 2 }));
  } else if (curr != null && finalVal != null && changeValueEl) {
    const computed = Number(finalVal) - Number(curr);
    safeSetText(changeValueEl, "₹ " + Number(computed).toLocaleString('en-IN', { maximumFractionDigits: 2 }));
  }

  if (data.change_percent != null && changePercentEl) {
    let pct = Number(data.change_percent);
    if (Math.abs(pct) <= 1 && Math.abs(pct) > 0) pct = pct * 100;
    safeSetText(changePercentEl, (pct % 1 === 0 ? pct.toFixed(0) : pct.toFixed(2)) + "%");
  } else if (curr != null && finalVal != null && changePercentEl) {
    const pct = ((Number(finalVal) - Number(curr)) / Number(curr || 1)) * 100;
    safeSetText(changePercentEl, (pct % 1 === 0 ? pct.toFixed(0) : pct.toFixed(2)) + "%");
  }

  if (data.direction && directionEl) {
    safeSetText(directionEl, String(data.direction).toUpperCase());
  } else if (curr != null && finalVal != null && directionEl) {
    const dir = Number(finalVal) > Number(curr) ? "UP" : (Number(finalVal) < Number(curr) ? "DOWN" : "FLAT");
    safeSetText(directionEl, dir);
  }
}

/* Main click handler */
if (predictBtn) {
  predictBtn.addEventListener('click', async () => {
    setLoading(true);
    clearError();
    metricsArea.textContent = "";
    if (finalValueEl) finalValueEl.textContent = "—";

    const payload = buildPayload();
    try {
      const res = await callApi(payload);
      let data = null;
      try {
        data = await res.json();
      } catch {
        showError("Invalid JSON response from API.");
        setLoading(false);
        return;
      }

      if (!res.ok) {
        const errMsg = data && (data.error || data.message) ? (data.error || data.message) : JSON.stringify(data || {});
        showError(`API error: ${errMsg}`);
        setLoading(false);
        return;
      }

      if (payload.mode === 'fast') {
        if (data.status !== 'ok') {
          showError(JSON.stringify(data));
          setLoading(false);
          return;
        }
        const preds = (data.predictions_inr || []).map(x => Number(x));
        const labels = data.timestamps || preds.map((_,i)=>`T+${i+1}`);
        const final = preds.length ? preds[preds.length - 1] : null;

        if (final != null && finalValueEl) {
          safeSetText(finalValueEl, "₹ " + Number(final).toLocaleString('en-IN',{maximumFractionDigits:2}));
        }
        metricsArea.textContent = `Mode: Fast | USD→INR: ${data.usd_inr || '—'}`;

        populateStatBoxes(data, final);
        renderChart(labels, preds, data.coin || payload.coin, payload.graph);

      } else {
        if (data.status && data.status !== 'ok') {
          showError(JSON.stringify(data));
          setLoading(false);
          return;
        }
        const preds = (data.predictions_inr || []).map(x => Number(x));
        const labels = data.timestamps || preds.map((_,i)=>`T+${i+1}`);
        const final = data.final_inr || (preds.length ? preds[preds.length-1] : null);

        if (final != null && finalValueEl) {
          safeSetText(finalValueEl, "₹ " + Number(final).toLocaleString('en-IN',{maximumFractionDigits:2}));
        }

        let metrics = data.metrics || (data.raw && data.raw.validation_metrics_live) || {};
        metricsArea.textContent = (metrics && typeof metrics === 'object')
          ? "Metrics: " + JSON.stringify(metrics)
          : String(metrics || '');

        populateStatBoxes(data, final);
        renderChart(labels, preds, data.symbol || payload.coin, payload.graph);
      }

    } catch (err) {
      showError("Network / JS error: " + (err && err.message ? err.message : String(err)));
      console.error(err);
    } finally {
      setLoading(false);
    }
  });
}

/* Enter key triggers prediction */
const stepsInput = document.getElementById('steps');
if (stepsInput) {
  stepsInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (predictBtn) predictBtn.click();
    }
  });
}
