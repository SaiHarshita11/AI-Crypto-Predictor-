# app/app.py
import os
import sys
import time
import threading
import pickle
import traceback
import json
import csv
from io import StringIO
from typing import Tuple, Dict, Any
from datetime import datetime, timedelta

from flask import Flask, request, jsonify, render_template, Response, redirect, url_for, session
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
import numpy as np
from tensorflow.keras.models import load_model

# Make sure parent folder (project root) is on path so imports work
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Import your existing helpers (if available)
try:
    from futurecoin_end2end import (
        fetch_klines_df,
        get_usd_to_inr_rate,
        COMMON_COINS,
        MODEL_DIR,
        LOOKBACK_HOURLY,
        LOOKBACK_DAILY,
        predict_live,
    )
except Exception as e:
    print("[WARN] Could not import futurecoin_end2end:", e)
    # Provide sensible fallbacks so app still starts for debugging in absence of the module
    COMMON_COINS = []  # empty list if not available
    MODEL_DIR = os.path.join(PROJECT_ROOT, "models")
    LOOKBACK_HOURLY = 48
    LOOKBACK_DAILY = 90
    def fetch_klines_df(*args, **kwargs):
        raise FileNotFoundError("futurecoin_end2end.fetch_klines_df not available")
    def get_usd_to_inr_rate():
        return 83.0
    def predict_live(*args, **kwargs):
        return {}

# Configure template/static to point to project-root folders
TEMPLATES_DIR = os.path.join(PROJECT_ROOT, "templates")
STATIC_DIR = os.path.join(PROJECT_ROOT, "static")

app = Flask(
    __name__,
    template_folder=TEMPLATES_DIR,
    static_folder=STATIC_DIR
)
CORS(app)

# ---- Session + DB setup ----
app.secret_key = os.environ.get("FLASK_SECRET", "dev-secret")
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get(
    "DATABASE_URL",
    f"sqlite:///{os.path.join(PROJECT_ROOT, 'futurecoin.db')}"
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

class PredictionHistory(db.Model):
    __tablename__ = "prediction_history"
    id = db.Column(db.Integer, primary_key=True)
    user_email = db.Column(db.String(255), nullable=True)
    coin = db.Column(db.String(50), nullable=False)
    timeframe = db.Column(db.String(20), nullable=False)
    steps = db.Column(db.Integer, nullable=False)
    mode = db.Column(db.String(20), nullable=False)
    predicted_value = db.Column(db.Float, nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

# Ensure DB tables exist (safe to call repeatedly)
with app.app_context():
    try:
        db.create_all()
        print("✅ Database tables created/verified.")
    except Exception as exc:
        print("⚠️ Failed to create DB tables:", exc)

# ---- Model cache ----
MODEL_CACHE: Dict[tuple, Dict[str, Any]] = {}
MODEL_CACHE_LOCK = threading.Lock()
MAX_CACHE_SIZE = int(os.getenv("MAX_CACHE_SIZE", "8"))

def _evict_if_needed():
    with MODEL_CACHE_LOCK:
        if len(MODEL_CACHE) <= MAX_CACHE_SIZE:
            return
        items = sorted(MODEL_CACHE.items(), key=lambda kv: kv[1]["loaded_at"])
        while len(MODEL_CACHE) > MAX_CACHE_SIZE and items:
            key_to_remove, _ = items.pop(0)
            MODEL_CACHE.pop(key_to_remove, None)

def load_model_and_scaler_cached(coin: str, freq: str) -> Tuple[object, object, threading.Lock]:
    key = (coin, freq)
    with MODEL_CACHE_LOCK:
        if key in MODEL_CACHE:
            MODEL_CACHE[key]["loaded_at"] = time.time()
            return MODEL_CACHE[key]["model"], MODEL_CACHE[key]["scaler"], MODEL_CACHE[key]["lock"]

    coin_dir = os.path.join(MODEL_DIR, coin)
    model_path = os.path.join(coin_dir, f"model_{freq}.h5")
    scaler_path = os.path.join(coin_dir, f"scaler_{freq}.pkl")

    if not (os.path.exists(model_path) and os.path.exists(scaler_path)):
        raise FileNotFoundError(f"Missing model/scaler for {coin} {freq}. Expected: {model_path} and {scaler_path}")

    model = load_model(model_path, compile=False)
    with open(scaler_path, "rb") as fh:
        scaler = pickle.load(fh)

    lock = threading.Lock()
    with MODEL_CACHE_LOCK:
        MODEL_CACHE[key] = {"model": model, "scaler": scaler, "loaded_at": time.time(), "lock": lock}
    _evict_if_needed()
    return model, scaler, lock

def iterative_predict_from_model(model, scaler, recent_close_array, lookback, steps):
    scaled = scaler.transform(recent_close_array.reshape(-1, 1)).flatten()
    s = scaled.copy()
    preds_scaled = []
    for _ in range(steps):
        inp = s.reshape(1, lookback, 1)
        p_scaled = float(model.predict(inp, verbose=0).flatten()[0])
        preds_scaled.append(p_scaled)
        s = np.roll(s, -1)
        s[-1] = p_scaled
    preds = scaler.inverse_transform(np.array(preds_scaled).reshape(-1, 1)).flatten().tolist()
    return preds

# --- Routes ---

@app.route("/__debug_template_check__")
def debug_template_check():
    base_cwd = os.getcwd()
    app_file = os.path.abspath(__file__)
    app_file_dir = os.path.dirname(app_file)
    tmpl_folder_config = app.template_folder or "templates"
    attempted = tmpl_folder_config
    project_templates = os.path.join(PROJECT_ROOT, "templates")
    app_relative_templates = os.path.join(app_file_dir, tmpl_folder_config)
    out = {
        "pwd": base_cwd,
        "project_root": PROJECT_ROOT,
        "app_file": app_file,
        "app_file_dir": app_file_dir,
        "app.template_folder_config": tmpl_folder_config,
        "attempted_template_abs_path": app_relative_templates,
        "templates_exists_at_attempted_path": os.path.exists(app_relative_templates),
        "templates_list_project_root": os.listdir(project_templates) if os.path.exists(project_templates) else [],
        "templates_list_app_relative": os.listdir(app_relative_templates) if os.path.exists(app_relative_templates) else []
    }
    return Response(json.dumps(out, indent=2), mimetype="application/json")

@app.route("/login")
def login_page():
    if os.path.exists(os.path.join(TEMPLATES_DIR, "login.html")):
        return render_template("login.html")
    return jsonify({"ok": True, "message": "login template not found"}), 200

@app.route("/logout")
def logout_redirect():
    # Clear server session and redirect to login page
    session.clear()
    return redirect(url_for("login_page"))

# API for frontend login.html to set server-side session
@app.route("/api/login_session", methods=["POST"])
def api_login_session():
    try:
        data = request.get_json(force=True)
        email = data.get("email")
        if email:
            session["user_email"] = email
            return jsonify({"status": "ok"})
        return jsonify({"status": "error", "error": "email required"}), 400
    except Exception as e:
        return jsonify({"status":"error","error":str(e)}), 500

@app.route("/")
def index():
    if os.path.exists(os.path.join(TEMPLATES_DIR, "index.html")):
        coins = [{"id": c, "label": c} for c in (COMMON_COINS if "COMMON_COINS" in globals() else [])]
        return render_template("index.html", coins=coins)
    return jsonify({"ok": True, "coins": COMMON_COINS if "COMMON_COINS" in globals() else []})

@app.route("/api/predict_fast", methods=["POST"])
def api_predict_fast():
    try:
        body = request.get_json(force=True)
        coin = (body.get("coin") or "").upper()
        timeframe = (body.get("timeframe") or "hourly").lower()
        steps = int(body.get("steps", 6))

        if coin not in COMMON_COINS:
            return jsonify({"status": "error", "error": f"coin must be one of {COMMON_COINS}"}), 400
        if timeframe not in ("hourly", "daily"):
            return jsonify({"status":"error","error":"timeframe must be hourly or daily"}), 400
        max_step = 23 if timeframe == "hourly" else 30
        if not (1 <= steps <= max_step):
            return jsonify({"status":"error","error":f"steps 1..{max_step}"}), 400

        model, scaler, model_lock = load_model_and_scaler_cached(coin, timeframe)
        lookback = LOOKBACK_HOURLY if timeframe=="hourly" else LOOKBACK_DAILY
        interval = "1h" if timeframe=="hourly" else "1d"
        df = fetch_klines_df(coin, interval, limit=lookback+2)
        if len(df) < lookback:
            return jsonify({"status":"error","error":f"Insufficient rows fetched: need {lookback}, got {len(df)}"}), 500
        close_arr = df['close'].values[-lookback:].astype(float)
        last_close = float(df['close'].values[-1])

        with model_lock:
            preds_usd = iterative_predict_from_model(model, scaler, close_arr, lookback, steps)

        usd_inr = get_usd_to_inr_rate()
        preds_inr = [float(p)*float(usd_inr) for p in preds_usd]
        current_inr = last_close * float(usd_inr)
        timestamps = [f"T+{i+1}" for i in range(steps)]

        final_inr = preds_inr[-1] if preds_inr else None

        # Save history (if user logged in server-side)
        user_email = session.get("user_email")
        if user_email:
            try:
                entry = PredictionHistory(
                    user_email=user_email,
                    coin=coin,
                    timeframe=timeframe,
                    steps=steps,
                    mode="fast",
                    predicted_value=final_inr
                )
                db.session.add(entry)
                db.session.commit()
            except Exception as e:
                # Don't fail the prediction if DB write has an issue; log and continue
                print("Warning: failed to save prediction history:", e)

        return jsonify({
            "status":"ok",
            "coin":coin,
            "timeframe":timeframe,
            "steps":steps,
            "usd_inr":float(usd_inr),
            "current_price_usd":float(last_close),
            "current_price_inr":float(current_inr),
            "predictions_usd":[float(x) for x in preds_usd],
            "predictions_inr":[float(x) for x in preds_inr],
            "timestamps":timestamps
        })

    except Exception as e:
        tb = traceback.format_exc()
        return jsonify({"status":"error","error":str(e),"trace":tb}), 500

@app.route("/api/predict", methods=["POST"])
def api_predict_full():
    try:
        body = request.get_json(force=True)
        coin = (body.get("coin") or "BTCUSDT").upper()
        timeframe = (body.get("timeframe") or "hourly").lower()
        steps = int(body.get("steps", 6))

        out = predict_live(coin=coin, freq=timeframe, steps_ahead=steps, mc_samples=20, compute_metrics_flag=True, metrics_val_samples=40)
        usd_inr = float(get_usd_to_inr_rate())
        preds_usd = [float(s["pred_price"]) for s in out.get("all_steps", [])]
        preds_inr = [p * usd_inr for p in preds_usd]
        final_inr = float(preds_inr[-1]) if preds_inr else None
        timestamps = [f"T+{i+1}" for i in range(len(preds_inr))]
        metrics = {
            "validation_metrics_precomputed": out.get("validation_metrics_precomputed"),
            "validation_metrics_live": out.get("validation_metrics_live"),
            "direction": out.get("direction"),
            "confidence_std_usd": out.get("confidence_std"),
            "usd_inr_rate": usd_inr
        }

        # Save history (if user logged in server-side)
        user_email = session.get("user_email")
        if user_email:
            try:
                entry = PredictionHistory(
                    user_email=user_email,
                    coin=coin,
                    timeframe=timeframe,
                    steps=steps,
                    mode="full",
                    predicted_value=final_inr
                )
                db.session.add(entry)
                db.session.commit()
            except Exception as e:
                print("Warning: failed to save prediction history:", e)

        return jsonify({
            "status":"ok",
            "symbol":coin,
            "freq":timeframe,
            "steps":steps,
            "timestamps":timestamps,
            "predictions_usd":preds_usd,
            "predictions_inr":preds_inr,
            "final_inr":final_inr,
            "metrics":metrics,
            "raw":out
        })
    except FileNotFoundError as fnf:
        return jsonify({"status":"error","error":str(fnf)}), 404
    except Exception as e:
        tb = traceback.format_exc()
        return jsonify({"status":"error","error":str(e),"trace":tb}), 500

# ---- History pages ----
@app.route("/history")
def history():
    user_email = session.get("user_email")
    if not user_email:
        return redirect(url_for("login_page"))
    entries = PredictionHistory.query.filter_by(user_email=user_email).order_by(PredictionHistory.timestamp.desc()).all()
    # pass timedelta so template can convert UTC -> IST for display
    return render_template("history.html", history=entries, timedelta=timedelta)

@app.route("/history/download")
def download_history():
    user_email = session.get("user_email")
    if not user_email:
        return redirect(url_for("login_page"))
    entries = PredictionHistory.query.filter_by(user_email=user_email).order_by(PredictionHistory.timestamp.desc()).all()

    si = StringIO()
    cw = csv.writer(si)
    cw.writerow(["Timestamp (IST)", "Coin", "Timeframe", "Steps", "Mode", "Predicted Value (INR)"])
    for r in entries:
        # convert UTC timestamp (stored as utc) to IST for CSV output
        try:
            ist_ts = (r.timestamp + timedelta(hours=5, minutes=30)).strftime("%Y-%m-%d %H:%M:%S")
        except Exception:
            # fallback: format raw timestamp
            ist_ts = r.timestamp.strftime("%Y-%m-%d %H:%M:%S") if r.timestamp else ""
        cw.writerow([
            ist_ts,
            r.coin,
            r.timeframe,
            r.steps,
            r.mode,
            "%.2f" % r.predicted_value if r.predicted_value else ""
        ])
    output = si.getvalue()
    si.close()

    return Response(
        output,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=prediction_history.csv"}
    )

if __name__ == "__main__":
    print("Starting FutureCoin app")
    print("Project root:", PROJECT_ROOT)
    print("Templates dir:", TEMPLATES_DIR)
    print("Static dir:", STATIC_DIR)
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5001")), debug=True, threaded=True)
